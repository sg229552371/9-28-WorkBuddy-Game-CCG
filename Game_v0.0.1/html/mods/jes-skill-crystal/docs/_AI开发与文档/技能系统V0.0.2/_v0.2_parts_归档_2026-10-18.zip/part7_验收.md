# 第七部　错误写法、冻结接口与验收

# 第34章　最容易犯的错误

**一句话结论：**绝大多数设计缺陷来自"把线性链当模型""把状态当事件""把推荐当确认"这三类。

| # | 常见误写 | 为什么错 | 正确写法 |
|---|---|---|---|
| 1 | "命中后爆炸，爆炸后留火" 写成一条线性尾巴 | 每一步都是独立的效果体，终止原因不同则后续不同 | 每一步一个效果体，用 hit / vanish(原因码) 派生（第7章） |
| 2 | 把"计时到点""波前到位""延迟结束"写成事件 | 全书事件只有 `hit`、`vanish` | 写成效果体内部状态；到点后终止则发 vanish（第6章） |
| 3 | "清场时补一个爆炸" | purge 不发 vanish、不派生、不补 hit | 清场只回收；需要"死亡爆炸"请显式设计为阵亡时的另一个技能（第7章） |
| 4 | 全闪避仍写"产生一条 hit" | D-05：全部份被闪避则无 hit | 写 `evaded_all` 结算记录；派生不触发（第11章） |
| 5 | "减免到 0 等于闪避" | 减免到 0 的 hit 仍成立，派生照常 | `any_reduced_to_zero=true`，hit 成立（第11章） |
| 6 | 用"超大速度"冒充瞬移 | 会穿过判定、被预算与碰撞分桶打乱 | 瞬移=零时长位移，无判定体，落点另生成实例（第8章） |
| 7 | 把 X 当命中数、实例数或伤害份数 | X=一轮内出手总次数 | 命中数用 hit 计，实例数用实例计（第10章） |
| 8 | 派生体无限继承全部修饰器 | 组合爆炸 | 默认只继承 `inheritable`；代数、预算、来源链三道闸（第20章） |
| 9 | 遗物触发直接"造成伤害" | 被动触发层不能直接造成伤害 | 只能生成效果体或挂修饰器（第21章） |
| 10 | 持续区域每跳读施法者最新属性 | 未声明时违反快照默认 | 默认出手时快照；需要实时则字段显式标 live（第18章） |
| 11 | 一个设计卡里写"看情况" | 无法测试 | 每格写默认值，缺栏写"使用默认"（第24章） |
| 12 | 把"推荐默认"写成"已确认" | 本书只有 D-01…D-08 是已确认 | 查附录 C 决策登记表 |
| 13 | 拿外部游戏的做法直接当规则 | 外部资料只是参考 | 标 E 编号，进规则时另立决策（附录 D） |
| 14 | 预算丢弃时发 vanish 触发派生 | 会在最拥挤时制造更多实例 | 预算丢弃按 purge，记 `debug_record`（第15章） |
| 15 | 用 `interrupted` 表示阵亡清理或目标丢失 | 阵亡清理属 purge；目标丢失按 `on_target_lost` | 见 R1、R7（第7章、第20章） |

---

# 第35章　方案评审清单

**一句话结论：**评审清单已并入第25章（A–G 七组共约 40 条，可勾选、可判定）；本章只给"提交评审前的 10 条硬门槛"。

## 35.1 硬门槛（任一不满足则不得进入评审）

| # | 门槛 | 对应章 |
|---|---|---|
| 1 | 设计卡无空栏，缺栏已写"使用默认" | 第24章 |
| 2 | 每个效果体都声明了载体与寿命（瞬时实例寿命=0） | 第5、8章 |
| 3 | 每个会终止的效果体列出了终止原因码，并说明哪些允许 vanish 派生 | 第7章 |
| 4 | 派生链标注了代数；超过默认 1 代已声明 | 第20章 |
| 5 | 重复命中已声明（`per_target_limit` / `rehit_interval_ticks` / `max_hits`），持续区域和环绕不得使用隐含默认 | 第14章 |
| 6 | 全闪避、减免到 0、无敌、免疫各给出一条预期 | 第11章 |
| 7 | 字段暴露声明写清哪些字段可被修饰器改 | 第17章 |
| 8 | 被动触发的技能写明 `internal_cooldown_ticks`、`max_chain_depth` | 第21章 |
| 9 | 玩家文字 ≤3 句，只写可见结果 | 第23章 |
| 10 | 至少 5 条"输入 → 预期"验收行，格式见 36.4 | 第36章 |

## 35.2 评审流程

1. 作者自查 35.1。
2. 评审人按第25章清单逐条勾选。
3. 每个不通过项写成"问题｜规则依据｜建议"，禁止只写"不合理"。
4. 评审结论只有三档：通过 / 带条件通过（列条件）/ 退回。

---

# 第36章　冻结接口与验收例子表

**一句话结论：**本章是实现与测试的直接依据；章内内容为"本版冻结的接口"，修改须走决策登记。冻结不等于用户已确认，状态见附录 C。

## 36.1 冻结范围

| 冻结项 | 位置 |
|---|---|
| 术语表 | 附录 A |
| 事件集 | 36.2：仅 `hit`、`vanish` |
| 原因码 | 36.3 |
| 字段词表与载荷 | 36.4 |
| 结算记录与 debug_record | 36.5 |
| 修饰器接口 | 36.6 |
| 运行时顺序 | 36.7 |
| 验收例子表 | 36.8 |

## 36.2 事件集（冻结）

| 事件 | 触发条件 | 载荷 |
|---|---|---|
| `hit` | 一次候选接触中至少一份伤害未被闪避 | 见 36.4 |
| `vanish` | 效果体自然终止 | `instance_id` `reason` `parent_ref` `tick` |

其余一律不是事件。

## 36.3 原因码（冻结）

| 码 | 含义 | 发 vanish | 允许 vanish 派生 |
|---|---|---|---|
| `hit_end` | 命中次数/穿透额度用尽；分裂时母体亦用此码 | 是 | 是 |
| `range_end` | 飞行距离/路径耗尽，位移按距离定义抵达终点；`on_target_lost: terminate` | 是 | 默认否，显式声明才可 |
| `landed` | 落到目标点/地面（仅限抛射） | 是 | 是 |
| `expired` | 持续时间到期；位移按固定时长结束 | 是 | 是（到期不额外跳伤） |
| `returned` | 回旋体回到施法者 | 是 | 是 |
| `interrupted` | 被打断或被拦截（含位移状态被打断） | 是 | 默认否，显式声明才可 |
| `instant_end` | 瞬时实例在其 tick 内结束 | 是 | 是 |
| （purge） | 清场、场景卸载、阵亡清理、预算丢弃 | **否** | **否** |

## 36.4 字段词表与载荷（冻结）

**instance：**`instance_id` `seq` `skill_id` `carrier`(`none`|`self`|`independent`) `caster_id` `generation` `parent_ref` `origin` `spawn_tick` `lifetime_ticks` `snapshot` `params` `hit_policy` `state`(`live`|`terminating`|`gone`)

**origin：**`origin_skill` `origin_cast_id` `chain_depth` `proc_mask`。`generation` 只数派生；`chain_depth` 数派生与被动触发，`chain_depth ≥ generation`。

**hit_policy：**`per_target_limit`（默认 1，按候选接触计）`rehit_interval_ticks`（可选）`max_hits`（可选，只计成立的 hit）。

**候选接触：**实例与目标由不重叠变重叠，或 `rehit_interval_ticks` 到点；每次只判定一次逐份闪避。

**hit 载荷：**`source_instance` `target_id` `parts[]{part_index, evaded, type, final_amount}` `any_reduced_to_zero` `killed` `tick` `seq`

**设计卡附加字段：**`shotgun_allowed`（默认 false）`on_target_lost`(`continue`|`terminate`，默认 `continue`) `attach_to_caster` `bind_owner`（召唤体，默认 true）`summon_cap` `internal_cooldown_ticks` `max_chain_depth` `allow_self_chain`（默认 false）`trigger_id`。

## 36.5 结算记录与调试记录（冻结）

| 名称 | 载荷 | 订阅方 |
|---|---|---|
| `hit_settled` | `source_instance` `target_id` `total` `killed` | 被动触发层 |
| `evaded_all` | `source_instance` `target_id` | 被动触发层 |
| `damage_taken` | `target_id` `total` `origin` | 被动触发层 |
| `cast_started` | `caster_id` `skill_id` `cast_id` | 被动触发层 |
| `debug_record` | `kind`(`budget_drop`|`proc_blocked`|`gen_limit`) `detail` `tick` | **仅测试与调试，任何层不得订阅触发逻辑** |

## 36.6 修饰器接口（冻结）

`modifier_id` `permission`(`mutate_number`|`add_behavior`|`mutate_live_instance`) `scope`(`own_skill` 默认|`tagged`) `inheritable`(默认 false) `targets[]` `stack_rule`。数值应用顺序 `set → add → mul → clamp`（`mul` 合并口径见第26章候选）。

## 36.7 运行时顺序（冻结，示意）

```text
每个 tick：
  1. 推进计时（受时间缩放）
  2. 闭环推进：索敌 / 前摇 / 出手 → 创建实例（本 tick 创建的实例下一 tick 才可命中）
  3. 实例按 seq 升序：运动 → 候选接触 → 逐份闪避 → hit 入 FIFO
  4. FIFO 逐个处理 hit：结算 → 写结算记录 → 派生
  5. 终止判定 → vanish 入 FIFO → 派生
  6. 被动触发层读结算记录 → 生成效果体（chain_depth+1）
  7. 回收；预算检查（超限按优先级 purge）
```

细节与边界以第14、15章为准。

## 36.8 验收例子表

### 36.8.1 通用规则验收（AC-36）

| 编号 | 输入条件 | 预期结果 | 验证点 |
|---|---|---|---|
| AC-36-01 | 一次接触三份伤害，A 闪避，B、C 未闪避 | 一条 hit，`parts` 含三份，A `evaded=true` | 11章；hit 只发一条 |
| AC-36-02 | 三份全部闪避 | 无 hit，有 `evaded_all`，不派生 | D-05 |
| AC-36-03 | 目标无敌 | 全部份视为闪避，无 hit | D-05 |
| AC-36-04 | 目标免疫某类型，该份未闪避 | 该份 `final_amount=0`，hit 成立 | D-05 |
| AC-36-05 | 位移状态中请求施放另一技能 | 被拒绝，不排队 | D-06、D-13 |
| AC-36-06 | 瞬时实例 | 同 tick 内 hit 与 `vanish(instant_end)` | D-01 |
| AC-36-07 | 效果体被 purge | 无 vanish、无 hit、无派生 | 第7章 |
| AC-36-08 | 同 tick 两实例命中同一目标 | 按 `seq` 升序结算，各一条 hit | 第14章 |
| AC-36-09 | 目标在本 tick 已死亡，后续实例再接触 | 不产生 hit | 第14章 |
| AC-36-10 | 本 tick 派生的子实例与目标重叠 | 本 tick 不命中，下一 tick 才可 | 第14章 |
| AC-36-11 | 实例超预算 | 先丢纯表现实例，判定实例最后，不挤根判定实例；purge；记 `debug_record(budget_drop)` | 第15章 |
| AC-36-12 | 相同种子、相同输入重跑 | 结果逐次一致 | D-09 待用户确认 |
| AC-36-13 | 遗物触发链：生成的效果体再次满足同一遗物条件 | 被来源链标记拦截，记 `debug_record(proc_blocked)` | 第21章 |
| AC-36-14 | 派生超过 `max_chain_depth` | 停止派生，记 `debug_record(gen_limit)` | 第20章 |
| AC-36-15 | 持续区域各跳读取施法者属性 | 使用出手时快照 | 第18章 |
| AC-36-16 | 全闪避的候选接触 | 仍占 `per_target_limit`，不消耗 `max_hits` | R2 |
| AC-36-17 | 召唤物数量超 `summon_cap` | 按规则丢最旧，purge | D-07 |
| AC-36-18 | 施法者阵亡 | 位移判定体与依附实例 purge；已生成独立实例继续；`bind_owner=true` 的召唤物 purge | R1 |

### 36.8.2 贯穿案例验收（AC-27…AC-33）

见第27–33章各章末尾的验收行，编号形如 `AC-27-01`。合稿版附表见本章末"AC 汇总"（由合稿脚本自动抽取，保证不漏）。

### 36.8.3 数量路径验收

| 编号 | 输入条件 | 预期结果 |
|---|---|---|
| AC-36-30 | 六次出手（三动作×两次） | X=6，不计成 12 |
| AC-36-31 | 一次出手生成三颗飞弹 | X 仍加 1，实例 +3 |
| AC-36-32 | 一颗穿透弹命中三目标 | 三条 hit，X 不变 |
| AC-36-33 | 一条 hit 含三份伤害 | 命中派生只执行一次 |

---
