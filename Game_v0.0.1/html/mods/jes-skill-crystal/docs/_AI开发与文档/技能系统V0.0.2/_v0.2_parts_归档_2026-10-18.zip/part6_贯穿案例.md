# 第27章　火炮抛射与地面火区

> **一句话结论**：炮弹是独立载体，正常落地时先做一次范围接触（至多一条 hit），再发 `vanish(landed)` 并派生火区；火区是另一个独立效果体，靠 `rehit_interval_ticks` 周期脉冲，到期只发 `vanish(expired)`，不额外跳伤。落点全闪避不影响留火。

## 27.0 全部案例通用的示例约定

| 约定 | 内容 |
|---|---|
| 时间基准 | 示例：60 tick/s，固定步长（见第14章；确定性 D-09 待用户确认）。tick 为绝对编号 |
| 实例命名 | `i1`、`i2`…，数字即 `seq`；`hit#n` 为本案例内 hit 的流水号 |
| 数值 | 伤害、半径、寿命、HP 全部为**示例**，不是平衡数据 |
| 闪避结果 | 推演中的闪避/暴击取值是“示例判定结果”，由可注入种子 RNG 给出（见第14章） |
| 记录格式 | `hit_settled{来源,目标,total,killed}` 等写法同契约词表 |
| `damage_taken` | 仅 total>0 时记录；total=0 的 hit 只记 `hit_settled`〔D-70 推荐默认〕 |
| 记录简写 | `damage_taken{目标,total,来源}` 的第三项是 `origin`（来源链标记）的**简写**，写作 `技能/chain_depth` 或仅技能 id；`vanish{实例,原因,tick,parent_ref}` 的 `parent_ref` 根实例写“无”，派生体写父实例 |

## 27.1 设计卡：重型火炮

| 栏位 | 内容 |
|---|---|
| **基础信息** | `skill_id=cannon`；玩家主动技能；选地面落点；冷却 240 tick（示例）；类别：伤害类 |
| **施法者闭环** | 索敌/选点 → 前摇 20 tick（示例）→ 出手×1（X=1）→ 冷却 → 回索敌。出手瞬间创建炮弹，施法者随即自由 |
| **效果体** | **炮弹 A**：载体 `independent`；寿命 60 tick（示例）；运动=抛射到选定落点（抛物线高度仅表现）。<br>**火区 B**：载体 `independent`；寿命 180 tick；运动=静止；`hit_policy`：`per_target_limit` 不限、`rehit_interval_ticks=60`（示例，火区须显式声明） |
| **命中与伤害份** | A 落地范围接触（半径 80，示例）：2 份——part0 物理 30、part1 火焰 10。B 每次脉冲：1 份火焰 8。逐份判闪避、逐份算减免（见第11章）；全闪避无 hit；某份减免到 0 仍可成立 hit |
| **派生** | A：`vanish(landed)` → 派生 B（第1代，`parent_ref=A`）；〔D-70 推荐默认〕落地时**先**做范围接触（hit 先于 vanish），再 vanish 并派生。B：`vanish(expired)` 无派生（本技能声明）。其余原因码均不派生 |
| **终止原因表** | 见 27.2 |
| **修饰器接口** | 暴露字段：`landing_radius`、`zone_duration_ticks`、`zone_pulse_interval_ticks`（即 B 的 `rehit_interval_ticks`）、`zone_pulse_damage`。水晶/遗物可 `mutate_number`；“落地后额外再生成一片火区”属 `add_behavior`，须技能声明可接 |
| **玩家文字** | 向目标地面发射炮弹，落地时爆炸并留下一片燃烧的火区。火区会持续灼烧范围内的敌人。炮弹在空中被拦截时不会留下火区。 |
| **依赖的规则** | 见第4–5章（效果体、生命周期）、第7章（派生与原因码）、第8章（独立载体）、第11章（逐份结算、D-05）、第12章（持续区域）、第14章（同帧顺序、重复命中、目标死亡）、第15章（预算）；第26章候选不涉及 |

## 27.2 终止原因表

| 实例 | 终止情形 | 原因码 | 发 vanish | 派生火区 |
|---|---|---|---|---|
| A | 正常落地（含空地、含落点目标全闪避） | `landed` | 是 | **是** |
| A | 空中被拦截 | `interrupted` | 是 | 否（默认否，本技能未声明） |
| A | 路径耗尽未落地（落点不可达） | `range_end` | 是 | 否（默认否） |
| A | 清场/场景卸载 | `purge` | **否** | 否 |
| B | 持续时间到期 | `expired` | 是 | 本技能无派生；到期不额外跳伤〔D-72 推荐默认〕 |
| B | 清场 | `purge` | **否** | 否 |

〔D-72 推荐默认〕脉冲 tick 若等于或晚于到期 tick，则该次脉冲不结算：到期优先于脉冲。
〔细化第14章同帧顺序与第12章延迟规则〕非瞬时派生体在创建 tick 不参与判定，从 `spawn_tick+1` 起参与；寿命 0 的瞬时派生体在同 tick 队尾处理。故 B 的首次脉冲排在 `spawn_tick+60`。

## 27.3 逐 tick 推演

场景（示例）：施法者 P；落点附近有 甲（火焰免疫，HP 100）、乙（HP 12）、丙（稍后走入）。

| tick | 发生什么 | 实例表变化 | 事件 / 结算记录 |
|---|---|---|---|
| 100 | P 选点并开始施放，前摇 20 tick | 无 | `cast_started{P,cannon,c1}` |
| 120 | 前摇结束，**出手**（X=1），创建炮弹 | +`i1` 炮弹 A（seq1，gen0，independent，寿命 60，snapshot 已取）live | 无（出手不是事件） |
| 121–179 | 炮弹飞行，i1 每 tick 移动；冷却在 120 起算（示例 240） | i1 live | 无 |
| 180 | i1 抵达落点，做范围接触，按距离近→远：<br>甲：part0 未闪避 30；part1 火焰免疫→减免到 0；<br>乙：两份全部闪避 | i1 live→terminating→gone；+`i2` 火区 B（seq2，gen1，parent=i1，寿命 180，到期 tick 360） | `hit#1`(i1→甲，parts=[30,0]，`any_reduced_to_zero=true`，killed=false)、`hit_settled{i1,甲,30,false}`、`damage_taken{甲,30,cannon}`、`evaded_all{i1,乙}`（**无乙的 hit**）、`vanish{i1,landed,180,parent_ref=无}` |
| 181–239 | 火区存活；甲、乙在区内；本区 i2 的首次脉冲在 240 | i2 live | 无 |
| 240 | **脉冲#1**：甲火焰免疫→8 减到 0；乙 8，HP 12→4 | i2 live | `hit#2`(i2→甲，final 0，`any_reduced_to_zero=true`)、`hit_settled{i2,甲,0,false}`；`hit#3`(i2→乙，8)、`hit_settled{i2,乙,8,false}`、`damage_taken{乙,8,cannon}` |
| 270 | 丙走入火区（非脉冲 tick，不结算） | 无 | 无 |
| 290 | 甲离开火区 | 无 | 无 |
| 300 | **脉冲#2**：区内乙、丙。乙 8，HP 4→死亡；丙 8 | i2 live | `hit#4`(i2→乙，killed=true)、`hit_settled{i2,乙,8,true}`、`damage_taken{乙,8,cannon}`；`hit#5`(i2→丙，8)、`hit_settled{i2,丙,8,false}`、`damage_taken{丙,8,cannon}` |
| 360 | 到期 tick 与第 3 次脉冲 tick 重合：**不结算脉冲**，火区到期；冷却同 tick 结束，P 回到索敌 | i2 live→gone | `vanish{i2,expired,360,parent_ref=i1}`（**无 hit**） |

小结：出手 1 次；实例 2 个；hit 5 条；vanish 2 条（`landed`、`expired`）；evaded_all 1 条。

## 27.4 验收行

| 编号 | 输入条件 | 预期结果 | 验证点 |
|---|---|---|---|
| AC-27-01 | 落点范围内唯一目标的所有伤害份全部闪避 | 无 hit，有 `evaded_all`；`vanish(landed)` 仍发；火区仍生成 | 留火只看终止原因，不看是否伤害到人 |
| AC-27-02 | 目标火焰免疫，火焰份减免到 0，物理份未闪避 | hit 成立，该份 `final_amount=0`，`any_reduced_to_zero=true` | D-05：免疫=减免为 0，hit 仍成立 |
| AC-27-03 | 火区到期 tick 恰为脉冲 tick | 仅 `vanish(expired)`，该 tick 无任何 hit | “到期不额外跳伤”，D-72 |
| AC-27-04 | 炮弹在空中被拦截 | `vanish(interrupted)`；不派生火区 | 默认 `interrupted` 不允许 vanish 派生 |
| AC-27-05 | 火区存活期间发生清场/场景卸载 | 无 vanish、无 hit、不派生；实例表清空，无新火区 | `purge` 不发 vanish，不留火区 |

---

# 第28章　双脉冲射击（六次出手）

> **一句话结论**：一轮三个动作、每动作两次出手，X=6；每次出手生成一颗独立的穿透脉冲弹，实例 6 个。一颗弹命中几个目标只增加 hit 条数，不增加 X，也不增加实例数。

## 28.1 设计卡：双脉冲射击

| 栏位 | 内容 |
|---|---|
| **基础信息** | `skill_id=twin_pulse`；玩家主动；朝目标方向；冷却 180 tick（示例，从最后一次出手起算，见第13章）；伤害类 |
| **施法者闭环** | 索敌 → [前摇 15 tick → 出手 → 间隔 6 tick → 出手]×3 个动作（动作间隔 示例）→ 冷却 → 回索敌。**X=6**，三动作各含两次出手；不是每次出手都套完整前摇+冷却（见第13章） |
| **效果体** | 脉冲弹×6，每次出手 1 颗：载体 `independent`；寿命 100 tick（示例）；运动=直线；`hit_policy`：`per_target_limit=1`，`max_hits=3` |
| **命中与伤害份** | 每条 hit 1 份能量伤害 12（示例）。同一实例对同一目标只会成立一次 hit；穿透额度只被 hit 消耗（主编裁决 R2）：候选接触（含全闪避）占用该实例对该目标的 `per_target_limit`，但不占 `max_hits` |
| **派生** | 无派生。`hit_end` 与 `range_end` 均不派生 |
| **终止原因表** | `hit_end`：命中 3 次后终止，发 vanish；`range_end`：寿命内没打满 3 次，飞到尽头，发 vanish；`interrupted`：被拦截，发 vanish；`purge`：不发 |
| **修饰器接口** | 暴露：`shots_per_action`（每动作出手数）、`pulse_damage`、`pierce_count`（即 `max_hits`）、`projectile_speed`。增加动作数改变 X，属闭环参数，须技能声明；水晶只能改数值，不能把本技能改成分裂（那是 `add_behavior`） |
| **玩家文字** | 连续射出六发穿透脉冲，每发最多穿透三个敌人。 |
| **依赖的规则** | 见第10章（X、连发、伤害份）、第13章（动作与多次出手）、第9章（判定维度）、第5章（生命周期）、第7章（原因码）、第14章（同帧顺序） |

## 28.2 逐 tick 推演

场景（示例）：甲、乙、丙一字排开；弹到甲需 20 tick，再到乙 +4，再到丙 +4。乙在 i3 经过时对全部份闪避。

| tick | 发生什么 | 实例表变化 | 事件 / 结算记录 |
|---|---|---|---|
| 0 | 施放开始，动作一前摇 | 无 | `cast_started{P,twin_pulse,c2}` |
| 15 | 出手① | +i1 | 无 |
| 21 | 出手②（动作一结束） | +i2 | 无 |
| 35 / 39 / 43 | i1 依次碰甲、乙、丙，三次均有 hit；第 3 次额度用尽 | i1 在 43 终止→gone | `hit#1`、`hit#2`、`hit#3`；`vanish{i1,hit_end,43}` |
| 41 / 45 / 49 | i2 同样穿透三目标 | i2 在 49 gone | `hit#4~6`；`vanish{i2,hit_end,49}` |
| 30–45 | 动作二前摇 | 无 | 无 |
| 46 | 出手③ | +i3 | 无 |
| 52 | 出手④（动作二结束） | +i4 | 无 |
| 66 / 70 / 74 | i3 碰甲 hit；碰乙**全闪避**；碰丙 hit。共 2 hit，额度剩 1 | i3 live | `hit#7`(甲)；`evaded_all{i3,乙}`（无 hit）；`hit#8`(丙) |
| 72 / 76 / 80 | i4 穿透三目标 | i4 在 80 gone | `hit#9~11`；`vanish{i4,hit_end,80}` |
| 77 | 出手⑤ | +i5 | 无 |
| 83 | 出手⑥（轮内最后一次出手） | +i6；冷却开始 | 无 |
| 97 / 101 / 105 | i5 穿透三目标 | i5 在 105 gone | `hit#12~14`；`vanish{i5,hit_end,105}` |
| 103 / 107 / 111 | i6 穿透三目标 | i6 在 111 gone | `hit#15~17`；`vanish{i6,hit_end,111}` |
| 146 | i3 寿命 100 到点，额度未用尽 | i3 gone | `vanish{i3,range_end,146}` |
| 263 | 冷却完（83+180），回到索敌 | 实例表空 | 无 |

核对表：

| 量 | 值 | 备注 |
|---|---|---|
| X（出手） | 6 | ①~⑥ |
| 效果体实例 | 6 | 无派生，不是 12 |
| hit | 17 | 5×3 + 2；乙对 i3 全闪避不成 hit |
| vanish | 6 | 5×`hit_end` + 1×`range_end` |
| 伤害份 | 17 份 | 每条 hit 1 份 |

## 28.3 验收行

| 编号 | 输入条件 | 预期结果 | 验证点 |
|---|---|---|---|
| AC-28-01 | 完整跑完一轮（三动作×两次出手） | X=6，出手发生的实例 6 个，不被计成 12 | 出手与实例分开计数（第10章） |
| AC-28-02 | 一颗穿透弹连续 hit 三个目标 | 该颗弹 3 条 hit；X 不变，实例数不变 | 一颗穿透弹多次命中不增加 X |
| AC-28-03 | 穿透弹碰到一个对全部份闪避的目标 | 无 hit，`evaded_all`；`max_hits` 不被消耗；弹继续飞；之后不再重试该目标 | R2 候选接触；终止原因取决于后续（可为 `range_end`） |
| AC-28-04 | 动作二结束后（出手④后）施法者被控制，闭环被打断 | 出手⑤⑥不再发生，X=4；已飞出的 i1~i4 不受影响，照常 hit/vanish | 〔D-74 推荐默认〕打断只取消未出手的出手；独立载体不随施法者终止 |
| AC-28-05 | 同一 tick 两颗不同实例的弹命中同一目标 | 各自成立一条 hit，按 `seq` 升序结算 | 不同实例互不共享 `per_target_limit`（同帧顺序见第14章） |

---

# 第29章　冲刺与被打断

> **一句话结论**：冲刺是自身载体——施法者进入位移状态，并伴随一个跟随判定体 H。位移走完以 `expired` 终止并可派生落地冲击；中途被打断则 H 以 `interrupted` 终止，**不派生**，已成立的 hit 保留，冷却不退还。

## 29.1 设计卡：突进冲刺

| 栏位 | 内容 |
|---|---|
| **基础信息** | `skill_id=dash`；玩家主动；沿选定方向；冷却 180 tick（示例），位移结束后开始计时（见第4章 D-12）；类别：位移 + 伤害 |
| **施法者闭环** | 索敌/选方向 → 前摇 10 tick（示例）→ 出手×1（X=1）：施法者进入**位移状态** → 位移期间闭环暂停，**不能施放其他技能**〔D-06 已确认〕→ 位移结束 → 冷却（位移结束后开始计时）→ 回索敌 |
| **效果体** | 跟随判定体 H：载体 `self`；寿命 30 tick（示例）=位移时长；运动=随施法者沿直线，4 单位/tick（示例）；`hit_policy`：`per_target_limit=1`。位移状态与 H 同生同灭 |
| **命中与伤害份** | 路径接触的每个敌人：1 份物理 20（示例）。全闪避无 hit（`evaded_all`），候选接触占用该目标的 `per_target_limit`〔R2 候选接触〕 |
| **派生** | H 正常走完 → `vanish(expired)` → 派生落地冲击 S：载体 `none`、寿命 0、范围半径 60、1 份物理 15（示例），S 自身 hit + `vanish(instant_end)` 同 tick 完成。`interrupted`/`purge`：不派生〔主编裁决 R5：按固定时长定义的位移状态终止用 `expired`；若按距离/终点定义则用 `range_end`；均不用 `landed`〕 |
| **终止原因表** | 见 29.2 |
| **修饰器接口** | 暴露：`dash_distance`/`dash_duration_ticks`、`dash_damage`、`landing_radius`。“被打断也触发落地冲击”属对 `interrupted` 的**显式声明**，须 `add_behavior` 且技能声明可接 |
| **玩家文字** | 向前冲刺，撞到路上的敌人造成伤害，到达终点时震击周围。冲刺中无法使用其他技能，被击晕会立刻停下。 |
| **依赖的规则** | 见第8章（自身载体、位移状态）、第7章（打断规则、原因码、派生）、第5章（生命周期）、第13章（冷却起点）、第14章（同帧顺序）、第11章（逐份结算） |

## 29.2 终止原因表

| 情形 | 原因码 | 发 vanish | 派生 S | 位移状态 |
|---|---|---|---|---|
| 位移时长走完 | `expired` | 是 | 是 | 结束，施法者恢复可行动 |
| 被控制/击退等打断 | `interrupted` | 是 | **否** | 立即结束，施法者停在当前位置 |
| 被墙体/不可穿越物拦截 | `interrupted` | 是 | 否（技能未声明） | 立即结束 |
| 清场、场景卸载 | `purge` | **否** | 否 | 清除 |

〔D-76 推荐默认〕同一 tick 内打断与自然终止并存，**以打断为准**；打断先于该 tick 的接触处理，故被打断的 H 本 tick 不再产生 hit。已成立的 hit 不回滚。冷却口径引用第4章 D-12：位移结束（含被打断而提前结束）后开始计时；出手已发生，故按完整冷却，不退还、不缩短。

## 29.3 逐 tick 推演

场景（示例）：P 在 x=0 朝右冲刺。甲 x=40，乙 x=56（会全闪避），丙 x=100，丁在旁侧准备击晕 P。位置公式：x = 4×(tick−210)。`damage_taken` 第三项是 `origin` 的简写（技能/chain_depth），`vanish` 末项是 `parent_ref`。

| tick | 发生什么 | 实例表变化 | 事件 / 结算记录 |
|---|---|---|---|
| 200 | 施放开始，前摇 10 tick | 无 | `cast_started{P,dash,c3}` |
| 210 | **出手**：P 进入位移状态；冷却尚未开始 | +i1 判定体 H（seq1，carrier self，寿命 30，到期 tick 240） | 无 |
| 215 | P 的玩家试图施放另一技能 | 无 | 被拒绝，无 `cast_started`（D-06） |
| 220 | H 接触甲（x=40） | i1 live | `hit#1`(i1→甲，物理 20)、`hit_settled{i1,甲,20,false}`、`damage_taken{甲,20,origin=dash/0}` |
| 224 | H 接触乙（x=56），乙全闪避 | i1 live | `evaded_all{i1,乙}`（无 hit；乙被登记为 i1 已接触） |
| 226 | 丁的击晕命中 P。**先处理打断**：i1 终止，位移状态结束，P 停在 x=64；冷却从本 tick 起算（到 406） | i1 live→terminating→gone；**无** S | `vanish{i1,interrupted,226,parent_ref=无}`（无派生，无 hit） |
| 227–405 | P 被晕后恢复；冷却仍在计时；丙从未被接触 | 实例表空 | 无 |
| 406 | 冷却结束，回到索敌 | 无 | 无 |

**对照：正常到达（不打断）**。同场景无丁。tick 240：H 寿命到点，`vanish{i1,expired,240,parent_ref=无}`；同 tick 派生 S（i2，gen1，parent=i1，寿命 0），S 对 P 终点半径 60 内的戊结算 `hit#2`（15），随后 `vanish{i2,instant_end,240,parent_ref=i1}`。S 与 H 的 vanish 同 tick，先 H 后 S（派生体在父 vanish 之后创建，见第7章）。

## 29.4 验收行

| 编号 | 输入条件 | 预期结果 | 验证点 |
|---|---|---|---|
| AC-29-01 | 冲刺中途被击晕 | H 以 `interrupted` 终止并发 vanish；**无**落地冲击实例 | `interrupted` 默认不允许 vanish 派生 |
| AC-29-02 | 打断发生在 H 已 hit 甲之后 | 甲的 hit 与伤害保留；打断后不再有 hit | 已成立 hit 不回滚；〔D-76〕 |
| AC-29-03 | 打断与自然到期落在同一 tick | 原因码为 `interrupted`，不派生 S | 〔D-76〕打断优先 |
| AC-29-04 | 位移期间玩家输入另一技能 | 被拒绝，无 `cast_started`，位移不受影响 | D-06 位移状态期间不能施放其他技能 |
| AC-29-05 | 冲刺被打断后立即请求再次冲刺 | 冷却仍在，被拒绝；冷却从位移结束 tick（226）起算 180 tick，不因打断退还或缩短 | 冷却不因打断退还或缩短（第4章 D-12） |

---

# 第30章　穿透、分裂、弹射与连锁

> **一句话结论**：穿透是同一实例继续运动；分裂、弹射、连锁是 hit 上的派生。一次候选接触只执行一种碰撞行为（Split > Pierce > …，参考 E1）；**分裂时母体以 `hit_end` 终止，不继续穿透、不再计 `max_hits`；分裂体不再分裂、不爆炸，与母体同属一个家族，靠家族登记不二次命中同一目标**。外部做法参考 E1（PoE wiki「Projectile」）：每次碰撞只发生一种行为，Split 只能一次，分裂体视为同一投射物。

## 30.1 设计卡：裂变长矛

| 栏位 | 内容 |
|---|---|
| **基础信息** | `skill_id=split_spear`；玩家主动；朝目标；冷却 120 tick（示例）；伤害类 |
| **施法者闭环** | 索敌 → 前摇 12 tick（示例）→ 出手×1（X=1）→ 冷却 → 回索敌 |
| **效果体** | **母弹**（generation 0）：载体 `independent`；寿命 60；直线；`max_hits=1`，`per_target_limit=1`。**分裂体**×3（generation 1）：载体 `independent`；寿命 30；直线，相对母弹方向 −30°/0°/+30°（示例）；`max_hits=2`（可穿透一名敌人），`per_target_limit=1`，`split_budget=0` |
| **命中与伤害份** | 母弹：1 份物理 20；分裂体每次：1 份物理 8；爆炸 E：1 份火焰 10（均示例）。逐份闪避/减免见第11章 |
| **派生** | 母弹第一次**成立**的 hit（同一候选接触）执行 Split：派生 3 个分裂体；母体随即 `vanish(hit_end)`，不穿透；母弹的 `hit_end` 派生爆炸 E（瞬时，半径 40，示例，新家族）。若母弹的候选接触全闪避，则无 hit、不分裂，母弹继续飞行。分裂体：**不再分裂**，其 `vanish(hit_end)`/`range_end` **均不派生**（不爆炸） |
| **终止原因表** | 见 30.3 |
| **修饰器接口** | 暴露：`split_count`、`split_angle`、`child_damage`、`child_pierce_count`（分裂体 `max_hits`）、`explode_radius`。水晶可 `mutate_number`；给母弹加 `pierce_count` 也不改变首次 hit 分裂终止（Split 优先于 Pierce）；“分裂体也爆炸 / 可再分裂”是**新行为**，须 `add_behavior`，且 `inheritable=false`（默认）时不会传给分裂体 |
| **玩家文字** | 掷出长矛，命中第一个敌人时裂成三支小矛，并在命中处爆炸。小矛各可穿透一名敌人。 |
| **依赖的规则** | 见第7章（派生、派生代数、原因码）、第9–10章（判定、连发/穿透）、第11章（逐份结算）、第14章（同帧顺序、重复命中）、第15章（预算）、第20章（来源链标记、chain_depth、防循环） |

## 30.2 本案例用到的规则

| 规则 | 内容 |
|---|---|
| 候选接触〔主编裁决 R2〕 | 实例与目标由不重叠变重叠，或 `rehit_interval_ticks` 到点，各算一次**候选接触**，只判定一次（逐份闪避）。`per_target_limit` 与重复命中计时按候选接触计，无论是否成立 hit；`max_hits` 只计成立的 hit；全闪避不产生 hit、不触发派生 |
| 碰撞行为优先级〔主编裁决 R6，参考 E1〕 | 一次候选接触只执行一种：Split > Pierce > Fork > Chain > Return（参考做法）。Split 与 Pierce 互斥；分裂时母体以 `hit_end` 终止。〔D-77 推荐默认〕本书“弹射”对应 Fork 位次、“连锁”对应 Chain 位次 |
| 家族登记〔R2/R6；细化 D-xx，第20章〕 | 分裂传递 `family_id`（=母弹 `instance_id`）。按“已发生的候选接触”登记目标（含全闪避的）；同一家族内一个目标最多被一个成员候选接触一次。爆炸 E 等其他派生体新开家族 |
| 同 tick 竞争 | 家族成员同 tick 触达同一目标：按 `seq` 升序，先到者候选接触并登记，后到者**静默跳过**（无 hit、无 `evaded_all`，不耗 `max_hits`，继续飞行） |
| 与防霰弹的区别〔R12〕 | 防霰弹只管“同一次出手同时生成的独立实例”之间（E1 的做法）；父体与派生体、分裂体与母体之间用家族登记。二者是不同机制，本案例只用家族登记 |
| 派生体不继承派生规则〔D-79 推荐默认〕 | 派生体只带父声明“给子体”的参数；父弹自己的 vanish/hit 派生规则不自动传给子体，除非该规则 `inheritable=true` |
| 深度〔R3〕 | `generation` 只数派生；`chain_depth` 每次派生 +1（被动触发也 +1，见第33章）。分裂体与 E 均为 generation 1、`chain_depth` 1，上限 `max_chain_depth` 见第20章 |
| 弹射 / 连锁 | **弹射**＝同一实例命中后改向下一个未访问目标，继续生命周期（不是派生）；**连锁**＝`hit` 派生新实例射向未访问目标，携带 `visited[]` 与 `chain_remaining`，每代递减，不得“满额度重新开始”（见第20章）。二者都不新增事件 |

## 30.3 终止原因表

| 实例 | 终止情形 | 原因码 | 发 vanish | 派生 |
|---|---|---|---|---|
| 母弹 | 首个成立 hit 触发 Split | `hit_end` | 是 | 爆炸 E（分裂体已在 hit 上派生） |
| 母弹 | 寿命耗尽，从未有成立 hit | `range_end` | 是 | 否（默认） |
| 母弹 | 被拦截 | `interrupted` | 是 | 否（默认） |
| 分裂体 | `max_hits` 用尽 | `hit_end` | 是 | **否**（不爆炸） |
| 分裂体 | 寿命耗尽 | `range_end` | 是 | 否 |
| 任意 | 清场 | `purge` | **否** | 否 |

## 30.4 逐 tick 推演

场景（示例）：甲 HP 50（在 O 点）、乙 HP 50（距甲 25）、丁 HP 8、戊 HP 50（会全闪避）、丙 HP 50。母弹 i1 在 tick 300 出手。

| tick | 发生什么 | 实例表变化 | 事件 / 结算记录 |
|---|---|---|---|
| 300 | 出手 | +i1 母弹（seq1，gen0，depth0，family=i1，寿命 60） | 无 |
| 310 | i1 对甲产生**候选接触**，未闪避，hit 成立 → Split 可用，执行：甲 HP 50→30；母体 `hit_end` 终止；`max_hits` 1/1 | +i2、i3、i4 分裂体（seq2–4，gen1，depth1，parent=i1，family=i1，`split_budget=0`，`max_hits=2`）；i1 live→gone | `hit#1`(i1→甲 20)、`hit_settled{i1,甲,20,false}`、`damage_taken{甲,20,split_spear}`；`vanish{i1,hit_end,310,parent_ref=无}`；登记 family{甲} |
| 310（同 tick，E 在队尾处理） | i1 的 `hit_end` 派生 E（半径 40）：甲、乙在内，各 10；E 是新家族，其候选接触不受 i1 家族登记约束 | +i5 E（seq5，gen1，depth1，parent=i1，family=i5，寿命 0）→ gone | `hit#2`(i5→甲 10)、`hit#3`(i5→乙 10)，各带 `hit_settled`、`damage_taken`；`vanish{i5,instant_end,310,parent_ref=i1}` |
| 311–313 | 分裂体各自飞行（从 spawn+1 起判定，见第14章） | — | 无 |
| 314 | i2 对丁候选接触，未闪避，8 点致死。Split 不可用（`split_budget=0`）→ Pierce：`max_hits` 1/2，继续飞行 | i2 live | `hit#4`(i2→丁 8)、`hit_settled{i2,丁,8,true}`、`damage_taken{丁,8,split_spear}`；登记 family{甲,丁} |
| 320 | i2 对戊候选接触，**全闪避**：无 hit，不分裂，`max_hits` 仍 1/2，i2 继续；戊被登记 | i2 live | `evaded_all{i2,戊}`；登记 family{甲,丁,戊} |
| 322 | i3 飞线经过戊：戊在家族登记中 → **静默跳过** | i3 live | 无 |
| 326 | i3 与 i4 同 tick 触达丙。按 `seq`：i3 先候选接触，hit，`max_hits` 1/2；i4 后到，丙已登记 → 静默跳过 | i3、i4 live | `hit#5`(i3→丙 8)、`hit_settled{i3,丙,8,false}`、`damage_taken{丙,8,split_spear}`；登记 family{甲,丁,戊,丙} |
| 330 | i4 飞线经过甲：甲已登记 → 静默跳过 | i4 live | 无 |
| 340 | i2、i3、i4 寿命到点（310+30） | 三者 gone | `vanish{i2,range_end,340,parent_ref=i1}`、`vanish{i3,range_end,340,parent_ref=i1}`、`vanish{i4,range_end,340,parent_ref=i1}`（均无派生，不爆炸） |

小结：hit 5 条；Split 只发生 1 次（母弹首个成立 hit）；分裂体 3 个，最大 generation 为 1；爆炸只有 1 个，来自母弹 `hit_end`；母弹 `max_hits` 为 1/1，分裂体 i2 因全闪避不计，仍为 1/2。

## 30.5 验收行

| 编号 | 输入条件 | 预期结果 | 验证点 |
|---|---|---|---|
| AC-30-01 | 分裂体在寿命内成立 hit | 不再派生分裂体（`split_budget=0`）；实例最大 generation 为 1 | 分裂体不可再分裂（R6、E1 的 Split 只能一次） |
| AC-30-02 | 母弹已候选接触甲，分裂体飞线再经过甲 | 无 hit、无 `evaded_all`，不耗 `max_hits` | 家族登记防二次命中（R2/R6） |
| AC-30-03 | 家族成员同 tick 触达同一目标 | 仅 `seq` 小者候选接触；后者静默跳过并继续飞行 | 家族登记同 tick 竞争；与 R12 的防霰弹是不同机制 |
| AC-30-04 | 母弹首个成立 hit 的候选接触 | 同一接触内：派生 3 个分裂体，母体 `vanish(hit_end)`；母体不穿透，不再有第二条 hit，`max_hits` 不再累加 | R6：Split 与 Pierce 互斥，分裂时母体 `hit_end` |
| AC-30-05 | 分裂体 `hit_end` 或 `range_end` | 只发 vanish，不生成爆炸 E | 派生体不继承派生规则（D-79） |
| AC-30-06 | 分裂体对某目标候选接触，全部伤害份闪避 | 无 hit、`evaded_all`；`max_hits` 不消耗；该目标被家族登记，其他成员不再接触它 | R2：候选接触占用限额，不占 `max_hits` |
| AC-30-07 | 连锁变体：`chain_remaining=2`，目标 A→B→C→D 均存活 | 派生 2 代后停止；`visited[]` 带入子体，不回头打 A；各代 `chain_depth` 每代 +1 | 额度递减不重置；R3、第20章 |

---

# 第31章　瞬时近战扇形

> **一句话结论**：瞬时近战是寿命 0 的无载体实例：出手所在 tick 内，它先逐目标结算 hit，再发 `vanish(instant_end)`，不跨 tick。扇形内每个目标各自成一条 hit，不是一条 hit 里的多份；本 tick 已死的目标不会被后面的实例再 hit。

## 31.1 设计卡：扇形斩

| 栏位 | 内容 |
|---|---|
| **基础信息** | `skill_id=fan_slash`；玩家主动（召唤物 Q 也持有同款，走自己的闭环，见 D-07）；冷却 45 tick（示例）；伤害类 |
| **施法者闭环** | 索敌/定方向 → 前摇 6 tick（示例）→ 出手×1（X=1）→ 冷却 → 回索敌 |
| **效果体** | 瞬时实例：载体 `none`；`lifetime_ticks=0`；运动=无；扇形半径 90、张角 120°（示例，出手时快照朝向）；`hit_policy` 默认（每实例每目标 1 次） |
| **命中与伤害份** | 每个命中目标：1 份物理 30（示例）。扇形内每个存活目标各自独立结算（不是一条 hit 里放三份）；全闪避无 hit；减免到 0 仍有 hit。候选目标按距离升序，等距按 `target_id`〔D-80 推荐默认〕 |
| **派生** | 本技能无派生。`vanish(instant_end)` 允许派生（如“挥击后留下残影判定”），但需要 `add_behavior`，本卡未启用 |
| **终止原因表** | `instant_end`：每个实例必经，发 vanish；`purge`：若实例在其处理前被清场，则不发 vanish、不补 hit；无其他原因 |
| **修饰器接口** | 暴露：`fan_radius`、`fan_angle`、`fan_damage`。水晶可 `mutate_number`；“挥击额外生成一道剑气”是新行为，须 `add_behavior`；`mutate_live_instance` 对本技能无意义（实例不存在于 tick 之间） |
| **玩家文字** | 挥击前方扇形区域内的所有敌人。 |
| **依赖的规则** | 见第5章（瞬时实例=寿命 0）、第6章（hit/vanish、killed 标记）、第10章（伤害份与 hit 的关系）、第11章（逐份结算、D-05）、第12章（瞬时扇形）、第14章（同帧顺序、目标死亡） |

## 31.2 补充规则

| 规则 | 内容 |
|---|---|
| 目标死亡即时生效〔细化第14章目标死亡规则〕 | 目标 HP 归零后立即标记“已死”。同一 tick 内之后处理的任何实例，候选目标列表里不再含它：**无 hit、无 `evaded_all`、不耗额度** |
| 击杀只记一次〔D-82 推荐默认〕 | `killed=true` 只出现在致死的那一条 hit（及其 `hit_settled`）上；之后即使还有实例指向该目标，也不再产生击杀记录 |
| 瞬时实例的处理时点 | 出手 tick 创建后，在该 tick 队尾（所有已存在实例处理完之后）按 `seq` 升序逐个处理（同 第14章同帧顺序）。同 tick 的两个瞬时实例，`seq` 小者先结算 |

## 31.3 逐 tick 推演

场景（示例）：P 与召唤物 Q 在同一 tick 各出手一次 `fan_slash`。P 的扇形内有：甲（HP 50，距 20）、乙（HP 40，距 40，会全闪避）、丙（HP 30，距 55，物理免疫）、戊（HP 10，距 70）；丁在扇形内但 tick 398 已死、尚未回收。Q 的扇形只覆盖戊和丁。

| tick | 发生什么 | 实例表变化 | 事件 / 结算记录 |
|---|---|---|---|
| 394 | P 前摇开始 | 无 | `cast_started{P,fan_slash,c4}` |
| 398 | 丁被别的来源击杀 | 丁标记已死 | 别的实例的 `hit_settled{…,丁,…,killed=true}` |
| 400 | P 前摇结束，**出手**：创建 i1（寿命 0）。同 tick，Q 的闭环也出手，创建 i2（`caster_id=Q`） | +i1（seq1）、+i2（seq2），均 spawn_tick=400，live | 无 |
| 400（队尾，处理 i1） | 候选按距离：甲、乙、丙、戊（丁已死，不在列表）。甲：未闪避 30，HP 50→20。乙：全闪避。丙：物理 30 减免到 0（`any_reduced_to_zero=true`）。戊：未闪避 30，HP 10→死 | i1 live→terminating | `hit#1`(i1→甲 30)、`hit_settled{i1,甲,30,false}`、`damage_taken{甲,30,fan_slash}`；`evaded_all{i1,乙}`（无乙的 hit）；`hit#2`(i1→丙，final 0)、`hit_settled{i1,丙,0,false}`（无 `damage_taken`）；`hit#3`(i1→戊 30)、`hit_settled{i1,戊,30,true}`、`damage_taken{戊,30,fan_slash}` |
| 400（i1 收尾） | i1 候选处理完毕 | i1 gone | `vanish{i1,instant_end,400}`（在 i1 所有 hit 之后） |
| 400（队尾，处理 i2） | Q 的候选：戊、丁均已死 → 候选列表为空 | i2 live→terminating→gone | **无 hit、无 `evaded_all`**；`vanish{i2,instant_end,400}` |
| 401 | 实例表中不存在 i1、i2（寿命 0，不跨 tick） | 回收完成 | 无 |

核对：i1 产生 3 条 hit（甲、丙、戊各一条）+ 1 条 `evaded_all` + 1 条 vanish；击杀记录只有 1 个（戊，来自 i1）；i2 没有任何 hit，仍发了自己的 `instant_end`。

## 31.4 验收行

| 编号 | 输入条件 | 预期结果 | 验证点 |
|---|---|---|---|
| AC-31-01 | 任意一次瞬时扇形出手 | 实例 `spawn_tick` 与 `vanish.tick` 相同；该实例所有 hit 先于 vanish、在同一 tick；下一 tick 实例表无此实例 | 瞬时实例同 tick 完成 hit 与 `instant_end` |
| AC-31-02 | 扇形内目标物理免疫（减免 100%） | hit 成立，`final_amount=0`，`any_reduced_to_zero=true`；`hit_settled.total=0`；无 `damage_taken`〔D-70〕 | D-05：免疫=减免为 0，hit 仍成立 |
| AC-31-03 | 同 tick，i1 与 i2（`seq` 1<2）先后指向同一 HP 10 目标，i1 伤害足以致死 | 仅 i1 一条 hit，`killed=true`；i2 对该目标无 hit、无 `evaded_all`；全局只有一次击杀记录 | 同帧双发打死同一目标只算一次击杀〔第14章目标死亡规则、D-82〕 |
| AC-31-04 | 扇形内三个存活目标，均未闪避 | 三条独立 hit，每条一个 `target_id`；不是一条 hit 带三个目标 | hit 的粒度=实例×目标 |
| AC-31-05 | 目标上一 tick 已死亡、尚未回收 | 不进入候选列表；本 tick 无针对它的 hit 或 `evaded_all` | 已死目标不再被 hit〔第14章目标死亡规则〕 |

---

# 第32章　地刺列、地震波与环绕

> **一句话结论**：三种形态都是独立载体的持续判定，区别只在“判定怎么推进”。地刺列选“多实例各带开始延迟”的模型，地震波是一个实例的半径扩张，环绕靠 `rehit_interval_ticks` 周期重复命中。重复命中计时以“实例×目标”为键；场上实例超限时，先丢纯表现实例，判定实例保留。

## 32.1 设计卡：大地回响

| 栏位 | 内容 |
|---|---|
| **基础信息** | `skill_id=earth_echo`；玩家主动；冷却 300 tick（示例）；伤害类。一次出手同时给出形态 A（地刺列）、形态 C（环绕）和表现实例；形态 B（地震波）是 A 的**替换版本**，同一技能不混用 A 与 B |
| **施法者闭环** | 索敌 → 前摇 20 tick（示例）→ 出手×1（X=1）→ 冷却 → 回索敌。出手只有一次；之后的 4 根地刺、2 个岩盘、6 个尘土都是**实例**，不是出手 |
| **效果体 A：地刺列** | 选“模型 2：一次出手生成多个实例，每个带开始延迟”（不与波前模型混用）。S1–S4：载体 `independent`；位置沿施法方向 40/80/120/160（示例）；`start_delay` 6×(n−1) tick（示例）；活动窗口 12 tick。开始 tick = `spawn_tick + max(1, start_delay)`〔第14章同帧顺序〕；**延迟期实例 live 但不判定**（内部状态，非事件）；开始 tick 做一次范围接触（半径 30，示例），`per_target_limit=1` |
| **效果体 B：地震波（替换 A）** | 一个实例 W：载体 `independent`；寿命 40 tick；判定半径每 tick +5（示例），从 0 扩张；近处先被覆盖；`per_target_limit=1`。半径扩张不是事件；到期 `vanish(expired)` |
| **效果体 C：环绕** | 岩盘 O1、O2：载体 `independent`；寿命 120 tick；绕施法者圆周运动，O2 与 O1 相位差 180°（示例）；`hit_policy`：`per_target_limit` 不限、`rehit_interval_ticks=30`（示例）。不是施法者每帧重新出手 |
| **效果体（表现）** | 尘土 V1–V6：载体 `independent`，**无判定**（无 `hit_policy`），仅表现；寿命 20 tick |
| **命中与伤害份** | 地刺每次：1 份物理 25；地震波每次：1 份物理 18；岩盘每次：1 份物理 10（均示例）。尘土无伤害份 |
| **派生** | 无。`expired`、`hit_end` 均不派生；`purge` 与超限丢弃不派生 |
| **终止原因表** | 见 32.3 |
| **修饰器接口** | 暴露：`spike_count`、`spike_spacing`、`orbit_count`、`orbit_rehit_interval`（即 `rehit_interval_ticks`）、`wave_speed`、`lifetime`。水晶可 `mutate_number`；“岩盘撞击额外生成裂地”是新行为，须 `add_behavior` |
| **玩家文字** | 地面依次刺出岩刺，两块岩盘绕你旋转并反复击打靠近的敌人。 |
| **依赖的规则** | 见第9章（判定与表现分离，尘土属表现维度）、第12章（波前、延迟、持续区域）、第14章（重复命中、同帧顺序）、第15章（实例预算、超限丢弃）、第7章（原因码、purge）、第5章（生命周期） |

## 32.2 补充规则

| 规则 | 内容 |
|---|---|
| 重复命中计时〔细化第14章重复命中规则〕 | 计时键=（实例，目标）。一个实例对一个目标首次接触后，`rehit_interval_ticks` 内不再接触；到点且目标仍在判定区内才再次结算。两个不同实例（O1、O2）对同一目标**各自独立计时** |
| 全闪避也推进计时〔细化第14章；R2 候选接触〕 | 候选接触无论是否产生 hit，都从该 tick 起重新计时（与 R2 候选接触 同口径），防止靠重掷闪避 |
| 离开不重置〔细化第14章重复命中规则〕 | 目标离开判定区再回来，不重置计时；回来时若间隔已满则立即再次结算 |
| 超限丢弃（细化第15章五级优先级，主编裁决 R8） | 场上实例数达上限（示例 12）时，按第15章五级优先级由低到高丢弃，纯表现实例最先丢；**不允许挤掉根判定实例**；新来的纯表现实例若场上已无更低者则不创建。被丢弃者按 `purge`：不发 vanish、不派生、不补 hit |
| 丢弃记录（主编裁决 R9） | 每次丢弃写一条 `debug_record{kind=budget_drop}`（含实例、tick、`detail`）。它不是事件、不是结算记录，任何层不得订阅它触发逻辑 |

## 32.3 终止原因表

| 实例 | 终止情形 | 原因码 | 发 vanish |
|---|---|---|---|
| 地刺 S1–S4 | 活动窗口走完 | `expired` | 是（无派生） |
| 地震波 W | 寿命 40 到期 | `expired` | 是 |
| 岩盘 O1、O2 | 寿命 120 到期 | `expired` | 是；到期 tick 若同时是重复命中 tick，**不结算**（D-72） |
| 尘土 V | 寿命走完 | `expired` | 是（若被丢弃则无） |
| 任意 | 超限丢弃、清场 | 无（`purge` 式） | **否** |

## 32.4 逐 tick 推演

场景（示例）：实例上限 12。出手前场上已有 8 个实例：5 个别的判定实例 + 3 个表现实例 e1–e3（e1 最旧）。敌人甲（HP 200）站在 S2 位置并在 O1/O2 轨道上；乙在 O1 轨道上，第一次接触会全闪避。

| tick | 发生什么 | 实例表变化 | 事件 / 结算记录 |
|---|---|---|---|
| 500 | **出手**（X=1），按顺序创建 S1–S4 | 8→12（满）：+S1(i10)、S2(i11)、S3(i12)、S4(i13) | 无 |
| 500 | 创建 O1：已满，挤掉最低优先级且最旧者 e1 | −e1，+O1(i14) | `debug_record{budget_drop,e1}`（**无 vanish**） |
| 500 | 创建 O2：同理挤掉 e2 | −e2，+O2(i15) | `debug_record{budget_drop,e2}` |
| 500 | 创建 V1–V6（纯表现）：场上最低是 e3（同级），不挤同级 → **6 个均不创建** | 不变（12） | `debug_record{budget_drop,V1…V6}`；**判定实例一个未丢** |
| 501 | S1 开始（delay 0 按 `max(1,0)`），范围内无目标 | S1 窗口至 513 | 无 |
| 506 | S2 开始，范围内甲：未闪避 25 | S2 窗口至 518 | `hit#1`(S2→甲 25)、`hit_settled{S2,甲,25,false}`、`damage_taken{甲,25,earth_echo}` |
| 510 | O1 首次接触甲：未闪避 10；O1×甲 下次可结算 tick=540 | — | `hit#2`(O1→甲 10)、`hit_settled{O1,甲,10,false}`、`damage_taken` |
| 512 | S3 开始，范围内无目标 | — | 无 |
| 513 | S1 窗口走完 | S1 gone | `vanish{i10,expired,513}` |
| 525 | O2 首次接触甲：10；O2×甲 下次=555 | — | `hit#3`(O2→甲 10) |
| 540 | O1×甲 间隔满，甲在区内：hit。同 tick O1 接触乙：全闪避，O1×乙 计时从此开始，下次 570 | — | `hit#4`(O1→甲 10)；`evaded_all{O1,乙}`（无乙的 hit） |
| 548 | 甲离开 O1/O2 判定区 | — | 无 |
| 555 | O2×甲 间隔满，但甲不在区内 → 不结算；计时不重置 | — | 无 |
| 560 | 甲回到 O2 判定区：间隔早已满足 → 立即结算，O2×甲 下次=590 | — | `hit#5`(O2→甲 10) |
| 570 | O1×甲 间隔满（540+30）：hit；O1×乙 间隔满且在区内：hit（未闪避） | — | `hit#6`(O1→甲 10)、`hit#7`(O1→乙 10) |
| 590 | O2×甲 下次=590：hit | — | `hit#8`(O2→甲 10) |
| 600 | O1×甲 下次=600：hit | — | `hit#9`(O1→甲 10) |
| 620 | O1、O2 寿命 120 到期；O2×甲 本应 620 结算，**到期优先，不结算** | O1、O2 gone | `vanish{i14,expired,620}`、`vanish{i15,expired,620}`（**无 hit**） |

说明：S2–S4 的其余 tick 略；本推演中没有任何 hit 来自尘土（无判定）。

## 32.5 验收行

| 编号 | 输入条件 | 预期结果 | 验证点 |
|---|---|---|---|
| AC-32-01 | 同一岩盘对同一目标，在 `rehit_interval_ticks` 内持续接触 | 间隔内无 hit；间隔满且仍在区内的 tick 再产生一条 hit | 重复命中间隔〔第14章重复命中规则〕 |
| AC-32-02 | O1、O2 同时覆盖同一目标 | 各自独立计时、各自产生 hit，互不抑制 | 计时键=实例×目标 |
| AC-32-03 | 目标一次全闪避；或离开判定区后返回 | 全闪避：无 hit 但计时推进；离开返回：计时不重置，间隔满即结算 | R2 候选接触、第14章重复命中规则 |
| AC-32-04 | 场上实例满额，同时新建判定实例与纯表现实例 | 先挤掉/拒绝纯表现实例（五级优先级最低者）；判定实例全部保留，不挤掉根判定实例；被丢弃者无 vanish、无派生（`debug_record{budget_drop}`） | 超限丢弃先丢纯表现〔D-83〕；丢弃≈purge |
| AC-32-05 | 地刺列 S3 的延迟期内 | S3 live 但不判定；其位置上的目标此期间不受伤；开始 tick 才结算，每目标 1 次 | 延迟是内部状态，非事件 |
| AC-32-06 | 地震波（形态 B）半径扩张经过目标 | 目标首次被覆盖时 1 条 hit；后续扩张不再命中同一目标；到期仅 `vanish(expired)` | 半径扩张不是事件；`per_target_limit=1` |

---

# 第33章　被动触发：遗物“击杀后生成效果体”

> **一句话结论**：遗物只读“结算记录”，只能生成效果体；防循环靠三层同时生效——深度上限 `max_chain_depth`、来源链标记（`proc_mask` 内的 `trigger_id`）、持有者内置冷却 `internal_cooldown_ticks`——外加预算兜底。击杀只触发一次，链在深度上限处停止，被拒绝的触发不留任何实例，只留一条 `debug_record`。

## 33.1 设计卡：亡魂连爆（遗物）

| 栏位 | 内容 |
|---|---|
| **基础信息** | `trigger_id=soul_burst`；遗物，玩家持有；被动，不占施法者闭环；伤害类（伤害只来自其生成的效果体）。触发条件：订阅结算记录 `hit_settled` 且 `killed=true`，且击杀实例的施法者为持有者（含其召唤物）。`internal_cooldown_ticks=5`（示例，按**持有者**计，被接受的触发起算）；`max_chain_depth=2`（示例）；`allow_self_chain=true`（触发配置的可选字段，默认 false，本遗物显式设为 true） |
| **施法者闭环** | **无**。被动触发层不进入索敌/前摇/出手/冷却；生成的效果体**不计入任何技能的 X**，也不产生 `cast_started` |
| **效果体** | 魂印 E：载体 `independent`，静止于被击杀目标的死亡位置；`start_delay=6` tick（示例）；开始 tick 做**一次**范围接触（半径 50，示例），活动窗口 1 tick，下一 tick 到期。沿用第32章地刺的“延迟期 live 但不判定”模型。来源链标记：`origin_skill=soul_burst`，`origin_cast_id` 沿用该次击杀所属 cast，`chain_depth`=触发源实例的 `chain_depth`+1，`proc_mask` 加入 `trigger_id=soul_burst`。E 由被动触发生成，不是派生：`generation=0`、`parent_ref` 为空〔R3；见 33.2〕 |
| **命中与伤害份** | E 开始 tick 对半径内每个存活敌人：1 份火焰 20（示例），逐份闪避/减免规则同第11章。被动触发层**自己不能造成伤害** |
| **派生** | 无。E 的 `vanish(expired)` 不派生 |
| **终止原因表** | 见 33.3 |
| **修饰器接口** | 暴露：`burst_radius`、`burst_damage`、`start_delay`、`internal_cooldown_ticks`（能否调低由第20章规定）。水晶/其他遗物可 `mutate_number`；**不暴露** `max_chain_depth` 与 `allow_self_chain`（安全红线，防止组合出无限链，见第20章）；“击杀后改为生成两个魂印”属 `add_behavior`，其生成物仍受下列三层约束 |
| **玩家文字** | 击杀敌人后，在其倒下之处留下魂印，片刻后爆裂。爆裂若再击杀敌人，会继续留下魂印，最多连锁两次。 |
| **依赖的规则** | 见第21章（被动触发层：只读结算记录、只生成效果体/挂修饰器）、第20章（来源链标记、`chain_depth`、作用域、实例预算、防循环）、第6章（结算记录非事件）、第12章（延迟）、第14章（同帧顺序、目标死亡）、第15章（预算）；第26章候选不涉及 |

## 33.2 防循环关口与补充规则

三层同时生效，缺一不可〔主编裁决 R4，内置冷却按持有者计〕：

| 序 | 关口 | 判断 | 不通过时 |
|---|---|---|---|
| 1 | 深度上限 | 触发源实例 `chain_depth` < `max_chain_depth`（示例 2） | 停止；`debug_record{kind=proc_blocked, detail=depth}` |
| 2 | 来源链标记 | 触发源 `proc_mask` 含本 `trigger_id` 且 `allow_self_chain=false` → 拒绝（本遗物 true，故放行） | 停止；`debug_record{kind=proc_blocked, detail=mask}` |
| 3 | 内置冷却 | 持有者在 `internal_cooldown_ticks` 内已接受过本触发器的触发 → 拒绝。被拒绝的触发不刷新冷却 | 停止；`debug_record{kind=proc_blocked, detail=cooldown}` |
| 4 | 预算（兜底） | 场上实例数未超限；超限按第15章五级优先级丢弃，且不挤掉根判定实例〔R8〕 | 丢弃，不发 vanish；`debug_record{kind=budget_drop}` |

| 规则 | 内容 |
|---|---|
| 深度的数法〔R3〕 | `generation` 只数派生；`chain_depth` 数因果链环节：**每次派生 +1，每次被动触发生成效果体也 +1**，故 `chain_depth ≥ generation`。派生与被动触发混在同一条链里时，两种环节都累加（AC-33-07） |
| 读取时点 | 触发层在每个 tick 的结算阶段末尾，按记录产生顺序读取 `hit_settled{killed=true}`；细化第21章。被拒绝的触发不产生任何实例 |
| 击杀只触发一次 | 同一目标的 `killed=true` 只有一条（D-82），不会因同 tick 双发而触发两次 |
| `debug_record` | `proc_blocked`、`budget_drop`、`gen_limit` 是 `debug_record` 的 `kind`〔R9〕。它不是事件、不是结算记录，**任何层不得订阅它触发逻辑**，只供测试与调试观察 |

## 33.3 终止原因表

| 实例 | 终止情形 | 原因码 | 发 vanish | 派生 |
|---|---|---|---|---|
| 魂印 E | 活动窗口走完 | `expired` | 是 | 否 |
| 魂印 E | 延迟期或窗口内被清场 | `purge` | **否**（也不补 hit） | 否 |
| 被关口拒绝的触发 | —（实例从未创建） | 无 | **无 vanish**（没有实例可终止） | 无 |

## 33.4 逐 tick 推演

场景（示例）：持有者 P 的技能 `bolt` 一次出手 X=3，同 tick 生成 i1、i2、i3。甲 HP 5（位置 a）；乙 HP 15（距 a 30）；丙 HP 100（距 a 30）；丁 HP 10（距乙 40）；戊 HP 8（远处）。`max_chain_depth=2`，`internal_cooldown_ticks=5`，tick 600 前冷却就绪。表中 `origin` 简写为 `skill/depth`。

| tick | 发生什么 | 实例表变化 | 事件 / 结算记录 |
|---|---|---|---|
| 600 | i1、i2 同 tick 到达甲（i1 `seq`=1 先）。i1 伤害 6，甲 HP 5→0；i2 处理时甲已死，候选移除 | i1、i2 终止 | `hit#1`(i1→甲 6)、`hit_settled{i1,甲,6,true}`、`damage_taken{甲,6,origin=bolt/0}`；`vanish{i1,hit_end,600,parent_ref=无}`、`vanish{i2,range_end,600,parent_ref=无}`；i2 **无 hit、无击杀记录** |
| 600（触发层） | 读到 `killed=true` 一条（甲，源 i1，`chain_depth`=0）。关口 1：0<2 通过；2：`proc_mask` 空，通过；3：冷却就绪，**接受并起算（到 605）**；4：通过。创建魂印 E1 | +i4 E1（seq4，gen0，`chain_depth`=1，`start_delay` 6，开始 tick 606，`proc_mask`={soul_burst}） | 无（触发不是事件） |
| 603 | i3 打死戊（HP 8）。触发层读到 `killed=true`（源 i3，depth0）：关口 1、2 通过；关口 3：603<605 **拒绝** | i3 终止；无新实例 | `hit#2`(i3→戊 8)、`hit_settled{i3,戊,8,true}`；`vanish{i3,hit_end,603,parent_ref=无}`；`debug_record{kind=proc_blocked, detail=cooldown}`（冷却未被刷新） |
| 606 | E1 开始，范围内乙、丙（按距离相等→`target_id`）：乙 20，HP 15→死；丙 20，HP 100→80 | E1 活动窗口 1 tick | `hit#3`(i4→乙 20)、`hit_settled{i4,乙,20,true}`、`damage_taken{乙,20,origin=soul_burst/1}`；`hit#4`(i4→丙 20)、`hit_settled{i4,丙,20,false}` |
| 606（触发层） | 读到 `killed=true`（乙，源 i4，depth1）。关口 1：1<2 通过；2：i4 的 `proc_mask` 含本 `trigger_id`，但 `allow_self_chain=true` → 通过；3：606≥605 就绪，**接受并起算（到 611）**；4：通过。在乙死亡位置创建 E2 | +i5 E2（seq5，gen0，`chain_depth`=2，开始 tick 612） | 无 |
| 607 | E1 窗口走完 | i4 gone | `vanish{i4,expired,607,parent_ref=无}` |
| 612 | E2 开始，范围内丁（距乙 40）：20，HP 10→死 | E2 活动窗口 1 tick | `hit#5`(i5→丁 20)、`hit_settled{i5,丁,20,true}`、`damage_taken{丁,20,origin=soul_burst/2}` |
| 612（触发层） | 读到 `killed=true`（丁，源 i5，depth2）。关口 1：2<2 **不通过**，链在此停止 | 无新实例 | `debug_record{kind=proc_blocked, detail=depth}` |
| 613 | E2 窗口走完；实例表无残留 | i5 gone | `vanish{i5,expired,613,parent_ref=无}` |

核对：被击杀 4 个目标（甲、戊、乙、丁），触发被接受 2 次（600、606）、被拒绝 2 次（冷却 603、深度 612）；链上魂印 2 个，不是 3 个；魂印不计入 `bolt` 的 X；被动触发层未造成任何直接伤害。

## 33.5 验收行

| 编号 | 输入条件 | 预期结果 | 验证点 |
|---|---|---|---|
| AC-33-01 | 同 tick 两个实例先后指向同一目标，前者致死 | 一条 `killed=true` 记录；遗物只触发一次，只生成一个 E | 同帧双发打死同一目标只算一次击杀（D-82） |
| AC-33-02 | 链：E1 击杀 → E2 → E2 再击杀（`max_chain_depth=2`） | E2 之后不再生成实例；记 `debug_record{proc_blocked, depth}`；链上 E 共 2 个，`chain_depth` 依次为 1、2 | 被动触发在深度上限处停止（第20章、R3） |
| AC-33-03 | 持有者在 `internal_cooldown_ticks` 内再有一次根击杀 | 不生成 E；记 `debug_record{proc_blocked, cooldown}`；冷却不被刷新 | 内置冷却按持有者计（R4） |
| AC-33-04 | 同一遗物把 `allow_self_chain` 置为默认值 false，E1 击杀了目标 | 不再触发；记 `debug_record{proc_blocked, mask}` | 来源链标记 `proc_mask` 内的 `trigger_id` 阻断同遗物回灌 |
| AC-33-05 | 魂印 E 的延迟期内发生清场 | E 无 vanish、无 hit；不补爆；已被拒绝的触发不留实例 | `purge` 与被拒绝的触发都不发 vanish |
| AC-33-06 | 任意修饰器试图改 `max_chain_depth` 或 `allow_self_chain` | 被拒绝（字段未暴露） | 组合安全从严（D-04 已确认） |
| AC-33-07 | 击杀实例是一个 `chain_depth`=1 的分裂体（派生 +1），其击杀触发本遗物 | 生成的 E 的 `chain_depth`=2；E 再击杀时不再触发 | 派生与被动触发各使 `chain_depth` +1（R3） |

---

## 待上报

| # | 问题 | 采用的默认 | 影响范围 |
|---|---|---|---|
| 1 | `damage_taken` 是否记录 total=0 的 hit | 不记，只记 `hit_settled`（D-70） | 第6章、第21章订阅口径；AC-27-02、AC-31-02 |
| 2 | 到期 tick 与周期脉冲/重复命中 tick 重合 | 到期优先，不结算（D-72，对应“到期不额外跳伤”） | 第12章、第14章；AC-27-03、32 章岩盘 |
| 3 | 施法者闭环被打断后已排队的出手 | 只取消未出手的出手；已创建的独立载体不受影响（D-74） | 第13章；AC-28-04 |
| 4 | 冲刺的打断与自然到期落在同一 tick | 以打断为准（D-76）；冷却按第4章 D-12 | 第7–8章；AC-29-03 |
| 5 | 派生体是否继承父的 vanish/hit 派生规则 | 默认不继承，除非该规则 `inheritable=true`（D-79） | 第20章；AC-30-05 |
| 6 | 本书“弹射/连锁”在碰撞行为优先级里的位次 | 对应 E1 的 Fork / Chain 位次（D-77） | 第9–10章；第30章 |
| 7 | 范围候选目标顺序、击杀记录唯一性 | 距离升序后按 `target_id`（D-80）；`killed=true` 只在致死的一条（D-82） | 第11章、第14章、第21章；AC-31-03、AC-33-01 |
| 8 | 被动触发生成的效果体的 `generation` | 取 0（不是派生）；`chain_depth` 按 R3 累加（本章采用） | 第5章、第20章、第21章 |
