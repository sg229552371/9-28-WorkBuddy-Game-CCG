# 附录 A　术语表

**一句话结论：**全书术语以本表为准；同义词不得另造。带"取代"的词是 v0.1 旧词，仅供对照。

| 术语 | 定义 | 详见 |
|---|---|---|
| 施放 | 玩家/怪物发起一次技能，从索敌到本轮结束。一次施放 = 一轮，对应一个 `cast_id` | 第4章 |
| 施法者闭环 | 索敌 → 前摇 → 出手 → 冷却 →（回到索敌）。取代 v0.1 的"层一" | 第4章 |
| 出手 | 闭环里一个瞬间：创建效果体或进入位移状态。X = 一轮内出手总次数；旧 Y、Z 分配作废 | 第10章 |
| 效果体 | 一切技能产物的统一容器（瞬时/独立载体/自身载体）。取代 v0.1 的"层二" | 第5章 |
| 实例 | 效果体的一次运行时存在，有唯一 `instance_id` 与创建序号 `seq` | 第5章 |
| 瞬时实例 | 寿命为 0 的效果体，同 tick 内完成 hit 与 `vanish(instant_end)` | 5.5 |
| 载体 | `none`（无载体）/`self`（自身，位移状态+跟随判定体）/`independent`（独立） | 第8章 |
| 位移状态 | 施法者被占用的运动状态，期间不能施放其他技能（D-06） | 4.7、第8章 |
| hit | 事件。一次候选接触中至少一份伤害未被闪避时成立，只发一条 | 第6、11章 |
| vanish | 事件。效果体自然终止时发出，带原因码 | 第6、7章 |
| 原因码 | `hit_end` `range_end` `landed` `expired` `returned` `interrupted` `instant_end` | 36.3 |
| purge（清场） | 清场/卸载/阵亡清理/预算丢弃。不发 vanish、不派生、不补 hit。不是原因码 | 第7章 |
| 伤害份 | 一条 hit 内独立判闪避、独立算减免的单位 | 第10、11章 |
| 候选接触 | 实例与目标由不重叠变重叠，或 `rehit_interval_ticks` 到点；每次只判一次逐份闪避；`per_target_limit` 按候选接触计 | 第14章 |
| 家族登记 | 分裂体与母体共享的"已发生候选接触"登记表，防二次命中；不同于防霰弹 | 第20、30章 |
| 防霰弹 | 同一次出手同时生成的独立实例对同一目标只有一个能接触 | 第14章 |
| 结算记录 | **非事件**只读记录：`hit_settled` `evaded_all` `damage_taken` `cast_started`，供被动触发层订阅 | 第6章 |
| `debug_record` | **非事件、非结算记录**，仅供测试与调试，任何层不得订阅触发逻辑；`kind`：`budget_drop` `proc_blocked` `gen_limit` | 6.7 |
| 被动触发层 | 读结算记录，只能生成效果体或挂修饰器，不能直接造成伤害 | 第21章 |
| 修饰器 | 水晶与遗物的统一机制，三档权限 | 第16–17章 |
| `mutate_number` | 改数值字段（仅暴露字段） | 第17章 |
| `add_behavior` | 加行为，只影响之后生成的实例 | 第17章 |
| `mutate_live_instance` | 改场上已存在的实例 | 第18章 |
| 快照 | 出手时施法者属性的冻结副本，默认用于该实例全寿命 | 第18章 |
| 派生 | 在 hit 或 vanish 上生成子效果体，`parent_ref` 指向父实例 | 第7章 |
| 派生代数 `generation` | 根为 0，只数派生 | 第7、20章 |
| `chain_depth` | 因果链深度，每次派生与每次被动触发各 +1，故 ≥ `generation` | 第20章 |
| 来源链标记 `origin` | `origin_skill` `origin_cast_id` `chain_depth` `proc_mask` | 第20章 |
| `internal_cooldown_ticks` | 触发配置的内置冷却，按持有者计 | 第21章 |
| 召唤物 | 拥有独立施法者闭环的效果体，受 `summon_cap` 约束，`bind_owner` 默认 true | 4.8、第22章 |
| 实例预算 | 同屏实例数的分级上限；超限按优先级 purge | 第15章 |
| 设计卡 | 一页写完一个技能的标准模板 | 第24章 |
| 层一 / 层二 | **v0.1 旧词，取代**：分别由"施法者闭环""效果体"替代 | 附录 E |
| 推荐默认 | AI 提出、本书暂用、未经用户确认的规则 | 第2章 |
| 已确认 | 用户明确拍板，仅 D-01…D-08 | 第2章 |
| 待用户确认 | 方向性、需用户表态，目前仅 D-09 | 第2章 |

---

# 附录 B　机器可读摘要

**一句话结论：**本摘要是第36章冻结接口的 YAML 形式，供程序与 AI 解析；与第36章冲突时以第36章为准。

```yaml
doc:
  name: 全新技能系统设计书
  version: v0.2
  date: 2026-10-17
  status: draft_awaiting_user_review
  supersedes_wording_of: v0.1
  confirmed_decisions: [D-01, D-02, D-03, D-04, D-05, D-06, D-07, D-08]
  pending_user_confirmation: [D-09]

events: [hit, vanish]

vanish_reasons:
  hit_end:     {derive_allowed: true}
  range_end:   {derive_allowed: default_false}
  landed:      {derive_allowed: true, only_for: projectile}
  expired:     {derive_allowed: true}
  returned:    {derive_allowed: true}
  interrupted: {derive_allowed: default_false}
  instant_end: {derive_allowed: true}
purge:
  emits_vanish: false
  derives: false
  is_reason_code: false

carriers: [none, self, independent]
instance_states: [live, terminating, gone]

instance_fields:
  - instance_id
  - seq
  - skill_id
  - carrier
  - caster_id
  - generation
  - parent_ref
  - origin
  - spawn_tick
  - lifetime_ticks
  - snapshot
  - params
  - hit_policy
  - state

origin_fields: [origin_skill, origin_cast_id, chain_depth, proc_mask]

hit_policy:
  per_target_limit: {default: 1, counts: candidate_contact}
  rehit_interval_ticks: {optional: true}
  max_hits: {optional: true, counts: successful_hits_only}

hit_payload:
  - source_instance
  - target_id
  - parts: [part_index, evaded, type, final_amount]
  - any_reduced_to_zero
  - killed
  - tick
  - seq

vanish_payload: [instance_id, reason, parent_ref, tick]

settlement_records:
  hit_settled:  [source_instance, target_id, total, killed]
  evaded_all:   [source_instance, target_id]
  damage_taken: [target_id, total, origin]
  cast_started: [caster_id, skill_id, cast_id]

debug_record:
  subscribable_by_logic: false
  kinds: [budget_drop, proc_blocked, gen_limit]

defense_semantics:
  invulnerable: all_parts_evaded_no_hit
  immune: part_reduced_to_zero_hit_stands
  all_parts_evaded:
    emits_hit: false
    emits_record: evaded_all
    derive: false
    zone_continues: true

modifier:
  fields: [modifier_id, permission, scope, inheritable, targets, stack_rule]
  permissions: [mutate_number, add_behavior, mutate_live_instance]
  scope_values: [own_skill, tagged]
  scope_default: own_skill
  inheritable_default: false
  numeric_order: [set, add, mul, clamp]

card_extra_fields:
  shotgun_allowed:       {default: false}
  on_target_lost:        {values: [continue, terminate], default: continue}
  attach_to_caster:      {default: false}
  bind_owner:            {default: true}
  summon_cap:            {required_for: summon}
  internal_cooldown_ticks: {required_for: passive_trigger}
  max_chain_depth:       {required_for: passive_trigger}
  allow_self_chain:      {default: false}
  trigger_id:            {required_for: passive_trigger}

collision_priority_reference: [split, pierce, fork, chain, return]

budget_priority_levels: 5
budget_rule:
  evict_root_hit_instances: false
  drop_method: purge
  record: debug_record

runtime:
  timestep: fixed
  rng: injectable_seeded
  netplay: false
  determinism_status: pending_user_confirmation
  tick_order: [advance_timers, closed_loop, instance_motion_and_contact, hit_fifo, termination_fifo, passive_triggers, recycle_and_budget]
  same_tick_spawn_hits_next_tick: true
  dead_target_no_new_hit: true
```

---

# 附录 D　外部资料与待核验清单

**一句话结论：**只有下表 E1–E7 的原文在 2026-10-17 实际抓取过，可标"外部事实"；它们只是参考，不是本书规则。

## D.1 外部事实（原文已抓取，抓取日期 2026-10-17）

| 编号 | 来源 | URL | 被本书用来参考的要点 |
|---|---|---|---|
| E1 | PoE wiki「Projectile」 | https://www.poewiki.net/wiki/Projectile | 碰撞行为优先级 Split > Pierce > Fork > Chain > Return、每次碰撞只一种；Split 只能一次且分裂体视为同一投射物；防霰弹；地面目标技能靠消失/爆炸范围伤害 |
| E2 | Noita wiki「Trigger」 | https://noita.wiki.gg/wiki/Trigger | 碰撞/Timer/Expiration 三种触发；Expiration 最多一次；载荷与外部修饰隔离（冷却/充能例外）；魔力不足优先保触发体 |
| E3 | RoR2 wiki「Proc Coefficient」 | https://riskofrain2.wiki.gg/wiki/Proc_Coefficient | 系数是缩放因子，乘到触发概率与持续时间；不影响暴击；技能系数不可被修饰（页面标注施工中） |
| E4 | UE「Gameplay Effects for GAS」（5.8） | https://dev.epicgames.com/documentation/unreal-engine/gameplay-effects-for-the-gameplay-ability-system-in-unreal-engine | Instant/Infinite/Has Duration；Instant 称 Executed；GE 资产不可变、运行时用 Spec；叠加策略；表现与逻辑分离 |
| E5 | Godot Area2D | https://docs.godotengine.org/en/stable/classes/class_area2d.html | `get_overlapping_*` 在物理步更新一次，非移动后立刻更新 |
| E6 | Godot Timer | https://docs.godotengine.org/en/stable/classes/class_timer.html | 受 `Engine.time_scale` 影响；可能依赖帧率或 `physics_ticks_per_second` |
| E7 | Fiedler「Fix Your Timestep」 | https://gafferongames.com/post/fix_your_timestep/ | 固定 dt + 累加器可使模拟与渲染解耦，得到逐次一致结果 |

## D.2 灵感，待核验（未抓到原文，不得当外部事实）

| 项 | 用在哪 | 核验方式 |
|---|---|---|
| RoR2 `procChainMask` 的具体实现 | 来源链标记 `proc_mask` 的灵感 | 抓取 RoR2 相关开发资料原文 |
| GAS 属性快照语义 | 快照默认（第18章）的灵感 | 抓取 GAS 属性捕获（Capture）文档 |
| GAS 的 Cancel 与 End 区别 | `purge` 与自然终止的区分灵感 | 抓取 GAS Ability 生命周期文档 |

## D.3 已移除

v0.1 附录 D 中的 `ivanwalsh.com` 条目来源不具体，v0.2 不再引用。

---

# 附录 E　版本记录

| 版本 | 日期 | 内容 |
|---|---|---|
| v0.1 | 更早 | 初版书稿（`全新技能系统设计书.md`，1994 行），原样保留供对照 |
| v0.2 | 2026-10-17 | 以 v0.1 为唯一起点重写；统一效果体模型；补全组合安全、被动触发层、非伤害模板、规模预算；新增决策登记表与冻结接口 |

## E.1 v0.2 对 v0.1 的主要变更

| # | v0.1 写法 | v0.2 处理 |
|---|---|---|
| 1 | "两条时间轴 / 层一 / 层二"，且术语表未定义 | 改为"施法者闭环 + 统一效果体"，术语表补齐，旧词标"取代" |
| 2 | 无载体与自身载体是特例 | 统一为瞬时实例与位移状态+跟随判定体（D-01） |
| 3 | 自然终止原因未编码，只有清场静默 | 自然终止必带原因码；`purge` 不是原因码 |
| 4 | X/Y/Z 旧分配 | 作废；X=一轮内出手总次数 |
| 5 | "持续时间与冷却取较大值"等含混表述 | 冷却属于施法者闭环，与效果体寿命无关（D-10） |
| 6 | 附录 B YAML 非法嵌套（`all_damage_parts_evaded: no_hit_but_zone_continues: true`） | 重写为合法 YAML（附录 B），并用解析器校验 |
| 7 | 文本含乱码字符"￼" | 清除 |
| 8 | 无决策登记表，推荐与确认混用 | 新增附录 C；状态只有 已确认/推荐默认/待用户确认 |
| 9 | 无组合安全 | 派生代数、来源链、作用域、预算、内置冷却（第20–21章） |
| 10 | 九项未定规则只列问题 | 每项给完整候选与推荐（第26章，D-60…D-68） |
| 11 | 评审清单仅适配旧模型 | 升级并并入第25章，第35章给硬门槛 |
| 12 | 附录 D 含具体性不足来源 | 只保留原文已抓取的 E1–E7 |

## E.2 本版未做

不写代码映射（D-08）；不开最终数值表；不做联网同步（D-09 待确认）；不改动任何游戏代码。
